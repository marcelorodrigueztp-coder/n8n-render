# n8n en Render - Deploy sin Git

Este proyecto contiene un Dockerfile listo para desplegar n8n gratis en Render.
